
import React, { useState } from "react";

const fakeUser = {
  email: "user@example.com",
  password: "password123",
};

export default function App() {
  const [user, setUser] = useState(null);
  const [loginForm, setLoginForm] = useState({ email: "", password: "" });
  const [error, setError] = useState("");
  const [selectedFile, setSelectedFile] = useState(null);
  const [animeType, setAnimeType] = useState("face");
  const [videoStatus, setVideoStatus] = useState("");

  const handleLogin = () => {
    if (
      loginForm.email === fakeUser.email &&
      loginForm.password === fakeUser.password
    ) {
      setUser({ email: loginForm.email });
      setError("");
    } else {
      setError("Invalid credentials");
    }
  };

  const handlePayment = (plan) => {
    alert("Payment simulated for: " + plan.name);
  };

  const handleGenerate = () => {
    if (!selectedFile) {
      alert("Please upload an image or story file.");
      return;
    }
    setVideoStatus("Generating your anime video...");
    setTimeout(() => {
      setVideoStatus("✅ Your anime video is ready! (This is a demo)");
    }, 3000);
  };

  const plans = [
    { name: "1 Month", amount: 299 },
    { name: "3 Months", amount: 599 },
    { name: "6 Months", amount: 999 },
    { name: "1 Year", amount: 1599 },
  ];

  if (!user) {
    return (
      <div style={{ padding: 20 }}>
        <h1>Login</h1>
        <input
          type="email"
          placeholder="Email"
          value={loginForm.email}
          onChange={(e) => setLoginForm({ ...loginForm, email: e.target.value })}
        />
        <br />
        <input
          type="password"
          placeholder="Password"
          value={loginForm.password}
          onChange={(e) =>
            setLoginForm({ ...loginForm, password: e.target.value })
          }
        />
        <br />
        {error && <p style={{ color: "red" }}>{error}</p>}
        <button onClick={handleLogin}>Login</button>
      </div>
    );
  }

  return (
    <div style={{ padding: 20 }}>
      <h1>Welcome, {user.email}</h1>

      <h2>Upload for Anime Video</h2>
      <input type="file" onChange={(e) => setSelectedFile(e.target.files[0])} />
      <br />
      <select
        value={animeType}
        onChange={(e) => setAnimeType(e.target.value)}
      >
        <option value="face">Face to Anime</option>
        <option value="avatar">Avatar Animation</option>
        <option value="story">Story-based</option>
      </select>
      <br />
      <button onClick={handleGenerate}>Generate Video</button>
      {videoStatus && <p>{videoStatus}</p>}

      <h2>Subscription Plans</h2>
      {plans.map((plan) => (
        <div key={plan.name} style={{ marginBottom: 10 }}>
          <strong>{plan.name}</strong>: ₹{plan.amount}{" "}
          <button onClick={() => handlePayment(plan)}>Subscribe</button>
        </div>
      ))}
    </div>
  );
}
